# Code analysis
## oficina-backend 
#### Branch fase01
#### Version 1.0.0 

**By: Administrator**

*Date: 2026-04-23*

*Analyzed the: 2026-04-23*

## Introduction
This document contains results of the code analysis of oficina-backend

API backend para oficina mecânica com autenticação, ordens de serviço e gerenciamento de clientes, veículos, serviços e peças.

## Configuration

- Quality Profiles
    - Names: Sonar way [Docker]; Sonar way [JavaScript]; 
    - Files: a04e4f11-544f-4a5c-a40c-fd4224122eec.json; cf8615ea-cddc-4803-992e-ade809a8ad90.json; 


 - Quality Gate
    - Name: Sonar way
    - File: Sonar way.xml

## Synthesis

### Analysis Status

Reliability | Security | Security Review | Maintainability |
:---:|:---:|:---:|:---:
A | A | E | A |

### Quality gate status

| Quality Gate Status | OK |
|-|-|

Metric|Value
---|---
New Issues|OK


### Metrics

Coverage | Duplications | Comment density | Median number of lines of code per file | Adherence to coding standard |
:---:|:---:|:---:|:---:|:---:
0.0 % | 0.7 % | 27.7 % | 52.0 | 99.4 %

### Tests

Total | Success Rate | Skipped | Errors | Failures |
:---:|:---:|:---:|:---:|:---:
0 | 0 % | 0 | 0 | 0

### Detailed technical debt

Reliability|Security|Maintainability|Total
---|---|---|---
-|-|0d 6h 10min|0d 6h 10min


### Metrics Range

\ | Cyclomatic Complexity | Cognitive Complexity | Lines of code per file | Coverage | Comment density (%) | Duplication (%)
:---|:---:|:---:|:---:|:---:|:---:|:---:
Min | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 0.0
Max | 482.0 | 177.0 | 2476.0 | 0.0 | 100.0 | 13.3

### Volume

Language|Number
---|---
Docker|8
JavaScript|4398
Total|4406


## Issues

### Issues count by severity and types

Type / Severity|INFO|MINOR|MAJOR|CRITICAL|BLOCKER
---|---|---|---|---|---
BUG|0|0|0|0|0
VULNERABILITY|0|0|0|0|0
CODE_SMELL|0|30|15|1|0


### Issues List

Name|Description|Type|Severity|Number
---|---|---|---|---
Cognitive Complexity of functions should not be too high||CODE_SMELL|CRITICAL|1
Functions should not have too many parameters||CODE_SMELL|MAJOR|8
Unused assignments should be removed||CODE_SMELL|MAJOR|4
Ternary operators should not be nested||CODE_SMELL|MAJOR|2
Optional chaining should be preferred||CODE_SMELL|MAJOR|1
Unused local variables and functions should be removed||CODE_SMELL|MINOR|3
Classes should not be empty||CODE_SMELL|MINOR|4
Exceptions should not be ignored||CODE_SMELL|MINOR|1
Negated conditions should be avoided when an else clause is present||CODE_SMELL|MINOR|7
Number literals should not have unnecessary decimal points or trailing zeros||CODE_SMELL|MINOR|2
Wrapper functions around built-in type conversion functions should be avoided||CODE_SMELL|MINOR|1
Node.js built-in modules should be imported using the "node:" protocol||CODE_SMELL|MINOR|5
Strings should use "replaceAll()" instead of "replace()" with global regex||CODE_SMELL|MINOR|7


## Security Hotspots

### Security hotspots count by category and priority

Category / Priority|LOW|MEDIUM|HIGH
---|---|---|---
LDAP Injection|0|0|0
Object Injection|0|0|0
Server-Side Request Forgery (SSRF)|0|0|0
XML External Entity (XXE)|0|0|0
Insecure Configuration|1|0|0
XPath Injection|0|0|0
Authentication|0|0|0
Weak Cryptography|0|1|0
Denial of Service (DoS)|0|2|0
Log Injection|0|0|0
Cross-Site Request Forgery (CSRF)|0|0|0
Open Redirect|0|0|0
Permission|0|3|0
SQL Injection|0|0|0
Encryption of Sensitive Data|0|0|0
Traceability|0|0|0
Buffer Overflow|0|0|0
File Manipulation|0|0|0
Code Injection (RCE)|0|0|0
Cross-Site Scripting (XSS)|0|0|0
Command Injection|0|0|0
Path Traversal Injection|0|0|0
HTTP Response Splitting|0|0|0
Others|1|0|0


### Security hotspots

Category|Name|Priority|Severity|Count
---|---|---|---|---
Permission|Recursively copying context directories is security-sensitive|MEDIUM|CRITICAL|2
Denial of Service (DoS)|Using slow regular expressions is security-sensitive|MEDIUM|CRITICAL|2
Permission|Running containers as a privileged user is security-sensitive|MEDIUM|MINOR|1
Weak Cryptography|Using pseudorandom number generators (PRNGs) is security-sensitive|MEDIUM|CRITICAL|1
Insecure Configuration|Having a permissive Cross-Origin Resource Sharing policy is security-sensitive|LOW|MINOR|1
Others|Disclosing fingerprints from web application technologies is security-sensitive|LOW|MINOR|1

